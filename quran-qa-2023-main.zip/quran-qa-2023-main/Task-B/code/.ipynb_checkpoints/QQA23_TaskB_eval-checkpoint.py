from __future__ import print_function
import argparse
import collections
import json
import re
import string
import sys
from collections import Counter

# ✅ تحسين: استخدام قائمة محدثة من الوقف ومقاييس إضافية
stopWords = {'من', 'الى', 'إلى', 'عن', 'على', 'في', 'حتى', 'و', 'ثم', 'أن', 'إن', 'لا', 'ما'}


def _is_punctuation(c):
    exclude = set(string.punctuation)
    exclude.update({'،', '؛', '؟'})
    return c in exclude


def normalize_answer_wAr(s):
    def remove_stopWords(text):
        return ' '.join([t for t in text.split() if t not in stopWords])

    def white_space_fix(text):
        return ' '.join(text.split())

    def remove_punc(text):
        return ''.join(ch for ch in text if not _is_punctuation(ch))

    return white_space_fix(remove_stopWords(remove_punc(s)))


def load_jsonl(input_path):
    data = []
    with open(input_path, 'r', encoding='utf-8') as f:
        for line in f:
            data.append(json.loads(line.rstrip('\n|\r')))
    print('Loaded {} records from {}'.format(len(data), input_path))
    return data


def f1_score(prediction, ground_truth):
    common = Counter(prediction) & Counter(ground_truth)
    num_same = sum(common.values())
    if num_same == 0:
        return 0
    precision = num_same / len(prediction)
    recall = num_same / len(ground_truth)
    return 2 * precision * recall / (precision + recall)


def exact_match(prediction, ground_truth):
    return int(prediction == ground_truth)


def evaluate(dataset, nbest_predictions, cutoff_rank):
    total = 0
    total_pap = 0.0
    total_em = 0.0
    total_f1 = 0.0

    for article in dataset:
        pq_id = article['pq_id']
        if pq_id not in nbest_predictions:
            continue

        golds = [normalize_answer_wAr(ans['text']) for ans in article['answers']]
        preds = [normalize_answer_wAr(pred['answer']) for pred in nbest_predictions[pq_id][:int(cutoff_rank)]]

        golds = [g.split() for g in golds]
        preds = [p.split() for p in preds if len(p) > 0]

        if len(golds) == 0:
            total += 1
            if len(preds) == 0:
                total_pap += 1.0
                total_em += 1.0
                total_f1 += 1.0
            continue

        # pAP@k
        ranks = []
        for rank, pred in enumerate(preds, start=1):
            max_f1 = max([f1_score(pred, g) for g in golds])
            if max_f1 > 0:
                ranks.append((rank, max_f1))

        score = 0.0
        hits = 0.0
        for r, f1 in ranks:
            hits += f1
            score += hits / r
        score = score / len(golds) if golds else 0.0
        total_pap += score

        # Exact Match & F1 for top-1 prediction
        if preds:
            top1 = preds[0]
            em = max([exact_match(top1, g) for g in golds])
            f1 = max([f1_score(top1, g) for g in golds])
            total_em += em
            total_f1 += f1

        total += 1

    print(f'pAP@{cutoff_rank} = {total_pap / total:.3f}')
    print(f'EM@1 = {total_em / total:.3f}')
    print(f'F1@1 = {total_f1 / total:.3f}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Enhanced MRC Evaluation without Farasa')
    parser.add_argument('--run_file', required=True, help='Prediction JSON file')
    parser.add_argument('--gold_answers_file', required=True, help='Gold JSONL file')
    parser.add_argument('--cutoff_rank', default=10)
    args = parser.parse_args()

    dataset = load_jsonl(args.gold_answers_file)
    with open(args.run_file, encoding='utf-8') as f:
        nbest_predictions = json.load(f)

    evaluate(dataset, nbest_predictions, int(args.cutoff_rank))