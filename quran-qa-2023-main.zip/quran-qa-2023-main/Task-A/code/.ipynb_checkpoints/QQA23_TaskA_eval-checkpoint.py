import sys
import argparse
import pandas as pd
import numpy as np
import pytrec_eval
import QQA23_TaskA_submission_checker as qqa23_sc
import logging

logger = logging.getLogger(__name__)
logger.setLevel(level=logging.DEBUG)

# ✅ تم توسيع مقاييس التقييم لتشمل مقاييس أكثر دقة وحداثة
METRICS = [
    'map',             # Mean Average Precision
    'recip_rank',      # Mean Reciprocal Rank
    'ndcg_cut_10',     # Normalized Discounted Cumulative Gain @10
    'P_10',            # Precision at 10
    'Rprec',           # R-Precision
    'bpref'            # Binary Preference (مفيد في حالة وجود qrels غير مكتملة)
]

qrels_columns = ["qid", "Q0", "docid", "relevance"]
run_columns = ["qid", "Q0", "docid", "rank", "score", "tag"]


def read_qrels_file(qrels_file):
    df_qrels = pd.read_csv(qrels_file, sep='\t', names=qrels_columns)
    df_qrels["qid"] = df_qrels["qid"].astype(str)
    df_qrels["docid"] = df_qrels["docid"].astype(str)
    return df_qrels


def read_run_file(run_file):
    split_token = '\t' if qqa23_sc.is_tab_sparated(run_file) else r'\s+'
    df_run = pd.read_csv(run_file, sep=split_token, names=run_columns)
    df_run["qid"] = df_run["qid"].astype(str)
    df_run["docid"] = df_run["docid"].astype(str)
    return df_run


def convert_to_dict(df, column1, column2, column3):
    grouped_dict = df.groupby(column1).apply(lambda x: x.set_index(column2)[column3].to_dict()).to_dict()
    return grouped_dict


def get_metric_list(results_dict, metric):
    return [inner_dict.get(metric, 0.0) for inner_dict in results_dict.values()]


def evaluate_zero_answer_questions(zero_answer_question_ids, df_run):
    scores = []
    run_question_ids = df_run["qid"].values

    for qid in zero_answer_question_ids:
        if qid not in run_question_ids:
            scores.append(0)
            continue

        retrieved_doc_ids = df_run.loc[df_run["qid"] == qid, "docid"].values
        if len(retrieved_doc_ids) == 1 and retrieved_doc_ids[0] == "-1":
            scores.append(1)
        else:
            scores.append(0)

    return scores


def evalaute_normal_questions(df_run, df_qrels):
    qrels_dict = convert_to_dict(df_qrels, 'qid', 'docid', 'relevance')
    run_dict = convert_to_dict(df_run, 'qid', 'docid', 'score')
    evaluator = pytrec_eval.RelevanceEvaluator(qrels_dict, METRICS)
    eval_res = evaluator.evaluate(run_dict)

    results = {}
    for metric in METRICS:
        metric_scores_list = get_metric_list(results_dict=eval_res, metric=metric)
        results.update({metric: metric_scores_list})
    return results


def main(args):
    output_file = args.output
    qrels_file = args.qrels
    run_file = args.run

    df_qrels = read_qrels_file(qrels_file)
    df_run = read_run_file(run_file)

    zero_answer_question_ids = df_qrels.loc[df_qrels["docid"] == "-1", "qid"].values
    df_qrels_normal = df_qrels.loc[~df_qrels['qid'].isin(zero_answer_question_ids)]
    df_run_zero = df_run[df_run['qid'].isin(zero_answer_question_ids)]
    df_run_normal = df_run[~df_run['qid'].isin(zero_answer_question_ids)]

    zero_scores = evaluate_zero_answer_questions(zero_answer_question_ids, df_run_zero)
    normal_scores = evalaute_normal_questions(df_run_normal, df_qrels_normal)

    final_results = {}
    for metric in METRICS:
        metric_scores = normal_scores[metric]
        metric_scores.extend(zero_scores)
        final_results[metric] = np.mean(metric_scores)

    df = pd.DataFrame([final_results])
    if output_file:
        df.to_csv(output_file, sep='\t', index=False)
        logger.info(f'Saved results to file: {output_file}')
    else:
        print(df.to_string(index=False))
    return final_results


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', '-r', required=True, help='Run file path')
    parser.add_argument('--qrels', '-q', required=True, help='QRELS file path')
    parser.add_argument('--output', '-o', help='Output result file')
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    main(args)