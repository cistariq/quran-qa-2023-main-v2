## Differences between [AyaTEC_v1.2](https://gitlab.com/bigirqu/quran-qa-2023/-/tree/main/Task-A/data) and [AyaTEC_v1.1](http://qufaculty.qu.edu.qa/telsayed/datasets/)

* AyaTEC_v1.2 is composed of 251 questions, 199 of which are from the original 207 questions of [AyaTEC_v1.1](http://qufaculty.qu.edu.qa/telsayed/datasets/); in addition to 52 new test questions for evaluating the systems in the PR task (Task A of Qur'an QA 2023). 

* Overall, AyaTEC_v1.2 includes a total of 37 *zero-answer* questions, 30 of which are from the original 33 *zero-answer* questions of AyaTEC_v1.1; in addition to 7 new ones.

* The [query relevance judgements (QRels) files of AyaTEC_v1.2](https://gitlab.com/bigirqu/quran-qa-2023/-/tree/main/Task-A/data/qrels) are over the gold (answer-bearing) passages of the [Thematic Qur'anic Passage Collection](https://gitlab.com/bigirqu/quran-qa-2023/-/tree/main/Task-A/data/Thematic_QPC) (QPC). Whereas the QRels files of AyaTEC_v1.1 are over the *direct* and *indirect* verse-based answers; each answer constitutes one or more consecutive verses from the Holy Qur'an. For a formal definition of a *direct* and *indirect* answer, refer to the [*AyaTEC* paper](https://dl.acm.org/doi/abs/10.1145/3400396) (p 11). 

    **Note**: After the end of the Qur'an QA 2023 shared task, and for compatibility purposes with AyaTEC_v1.1, we have also released the QRels files of AyaTEC_v1.2 over  *direct* and *indirect* verse-based answers [here](https://gitlab.com/bigirqu/quran-qa-2023/-/tree/main/Task-A/data/qrels/verse_based_answers). The *direct* (gold) answers to the questions in these files were used to create the QRels over QPC.  Each Qur’anic passage in the collection was considered relevant to the question, if it happened to comprise any of the gold (*direct*) answer(s) completely or partially. 

* The *zero-answer* questions are included in the QRels files *over QPC* for AyaTEC_v1.2, but they are not included in the QRels files *over verse-based answers* for both AyaTEC_v1.1 and AyaTEC_v1.2. 
